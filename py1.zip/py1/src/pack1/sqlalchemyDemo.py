from sqlalchemy import Column, String, create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy import create_engine ,engine_from_config

import tushare as ts
config = {
          'sqlalchemy.url':'mysql+pymysql://root:root@127.0.0.1/mysql?charset=utf8',
          'sqlalchemy.echo':True
          };
# df = ts.get_tick_data('600848', date='2014-12-22')
# engine = create_engine(config['sqlalchemy.url'], echo=True)
engine = engine_from_config(config);
DB_Session = sessionmaker(bind=engine)
session = DB_Session()
print (session.execute('show databases').fetchall())

print (session.execute('select * from user  ').first())
print (session.execute('select * from user  ').first())