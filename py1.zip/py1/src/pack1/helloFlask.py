
from flask import Flask, url_for, render_template,request
from logging  import  FileHandler 
import logging
app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello World!"


@app.route('/user/<username>')
def show_user_profile(username):
    # show the user profile for that user
    return 'User %s' % username

@app.route('/post/<int:post_id>')
def show_post(post_id):
    # show the post with the given id, the id is an integer
    return 'Post %d' % post_id

@app.route('/indexpage')
def index(): pass

@app.route('/login2', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return do_the_login()
    else:
        return show_the_login_form()
        
def do_the_login():
    return 'do_the_login' 

def show_the_login_form():
    return 'show_the_login_form' 



#http://127.0.0.1:8001/hellopage/?q=111
@app.route('/hellopage/')
@app.route('/hellopage/<name>')
def hellopage(name=None):
    searchword = request.args.get('q', '')
    print('searchword : ' ,searchword)
    app.logger.warning('A warning occurred (%d apples)', 42)
#     print('username : ' ,request.form['username'])
    return render_template('hello.html', name=name)

@app.route('/user/<username>')
def profile(username): pass

with app.test_request_context():
    print (url_for('index'))
    print (url_for('login'))
    print (url_for('login', next='/'))
    print (url_for('profile', username='John Doe'))
    
with app.test_request_context('/hello', method='POST'):
    # now you can do something with the request until the
    # end of the with block, such as basic assertions:
    assert request.path == '/hello'
    assert request.method == 'POST'
    
if __name__ == "__main__":
    app.debug =False;
    if not app.debug:
        fileHandler = FileHandler("logs/python1.log")
        fileHandler.setLevel(logging.DEBUG)
        app.logger.addHandler(fileHandler)
    app.run(port=8001)