'''
Created on 2017年2月13日

@author: wWX438999
'''
import platform;
import jinja2;
import werkzeug;
import pymongo;
import sys ; 
import flask ;
if __name__ == '__main__': 
    print (" Ecplise+PyDev=",platform.uname());
    print(" python =" ,sys.version);
    print(" python version_info =" , sys.version_info );
    print(" pymongo =" ,pymongo.version,pymongo.has_c());
    print(" jinja2 =" , jinja2.__version__); 
    print(" werkzeug =" , werkzeug.__version__);
    print(" Flask =" , flask.__version__);