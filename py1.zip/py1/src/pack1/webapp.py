def application(environ, start_response):
    start_response('200 OK', [('Content-Type', 'text/html')])
    output = '<h1>Hello, web!</h1>'.encode('utf-8');
    return [output];

#     output = "<html><body><p>Räksmörgås</p></body></html>".encode('utf-8')
#     start_response('200 OK', [
#         ('Content-Type', 'text/html; charset=utf-8'),
#         ('Content-Length', str(len(output)))
#     ])
# 
#     return  [output] 