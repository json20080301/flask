'''
Created on 2017年2月13日

@author: wWX438999
'''
import unittest

import pymongo; 
from pymongo import MongoClient
class Test(unittest.TestCase):

    
    def setUp(self):
        self.client = MongoClient("localhost", 27017)
        self.testdb = self.client.test
       

    def tearDown(self):
        pass


    def testCollection(self):
        coll = self.client.get_database("test").get_collection("my_collection");
        searchObj = coll.find().limit(10)
        for item in searchObj:
            print(item["x"])
        print (">>>>>>>>");
        
    def testUpsert(self):  
        coll = self.client.get_database("test").get_collection("products");
        coll.update_one({'_d': 10}, {'$inc': {'x': 3},'$currentDate': {'birthday': {'$type': "date"}}},upsert=True)
#         coll.update({_d:1}, {$set : {item : "apple"}, $setOnInsert : {defaultQty : 100}} , {upsert : true});
        
    def testInsert(self):
        objid =self.testdb.my_collection.insert_one({"x": 10}).inserted_id
        self.testdb.my_collection.insert_one({"x": 8})
        self.testdb.my_collection.insert_one({"x": 9})
        self.testdb.my_collection.insert_one({"x": 7})
        print(objid)
        print (">>>>>>>>");
        
    def testFind(self):
        searchObj =self.testdb.my_collection.find({"x": 10}) 
        for item in searchObj:
            print(item["x"])
        print (">>>>>>>>");
    
    def testFindAsc(self)  :      
        searchObj =   self.testdb.my_collection.find().sort("x", pymongo.ASCENDING);
        for item in searchObj: 
            print(item["x"])
        print (">>>>>>>>");
         
if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()